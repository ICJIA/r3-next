---
title: "Search"
showInSitemap: true
showInSidebar: true
showInFooter: true
summary: "R3 site search"
createdAt: "2020-02-14"
showToc: false
menuRank: 9999
dividerAfter: true
showAsCard: false
lang: "en"
---

<Search :resultLimit="1000" :resultAsNav="false" :focus="true"></Search>
